// MODULE
var vizOnApp = angular.module('vizOnApp', ['ngRoute', 'ngResource','angularBootstrapNavTree']);

// SERVICES
vizOnApp.factory('accessFac',function(){
	var obj = {}
	this.access = false;
	obj.getPermission = function(url,usr,pswd){    //set the permission to true
		hostString = url;
		//Console.log('hostString' + hostString + '  usr   ' +usr+'   pswd  '+pswd);
		connect(usr,pswd);
		if(issessionIdCreated){
		//	alert(sessionId);
		this.access = true;
		}
		if(!issessionIdCreated){
			//	alert(sessionId);
			console.log('httpStatusCd ' + httpStatusCd);
			console.log('httpStatusTxt '+httpStatusTxt);
		}
	}
	obj.checkPermission = function(){
		return this.access;				//returns the users permission level 
	}
	return obj;
});

// ROUTES

vizOnApp.config(function($routeProvider){
	$routeProvider
	.when('/login' ,{
        templateUrl: 'templates/login.htm',
        controller: 'loginController'
	})
	
	.when('/analysis' ,{
	templateUrl: "templates/analysis.htm",
	controller: 'analysisController',
	resolve:{
		"check":function(accessFac,$location){   //function to be resolved, accessFac and $location Injected
			if(accessFac.checkPermission()){    //check if the user has permission -- This happens before the page loads
				$location.path('/analysis');
			//	console.log('Access Granted!!!!'+ accessFac.checkPermission());
			}else{
				$location.path('/');				//redirect user to home if it does not have permission.
				//alert("You don't have access here");
				console.log('Access Denied!!!!');
			}
		}
	}
	})

	.when('/' ,{
	templateUrl: "templates/login.htm"
	});
});