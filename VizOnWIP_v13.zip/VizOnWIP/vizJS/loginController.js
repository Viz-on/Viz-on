vizOnApp.controller('loginController', ['$scope','accessFac','$location' , function($scope,accessFac,$location) {
    
	$scope.getAccess = function(){
		// Just for testing. We can remove the below hardcoded values during deployment.
		$scope.url = 'http://166.78.244.8:9522/analytics/';
		$scope.username = 'weblogic';
		$scope.password = 'w3bl0g1c123';
		//Just for testing ........................................
		accessFac.getPermission($scope.url,$scope.username,$scope.password);       //call the method in acccessFac to allow the user permission.
	//	console.log('username : '+ $scope.username+'   password  :  '+ $scope.password);
		if(accessFac.checkPermission()){
			$location.path('/analysis');
		}
		if(!accessFac.checkPermission()){
			$scope.error = 'Invalid URL/User/Password';
			console.log($scope.error);
		}
	}
        
    }]);