vizOnApp.controller('analysisController', ['$scope','$location' , function($scope,$location) {
$scope.currentUser;
 $scope.tableName = [] ;
 $scope.colName=[];
 var tables_list =[];
 $scope.selectedCols = [];
    getCurrentUser();
    $scope.currentUser = user;
            allSAsDropDown();
        //console.log(sareas);
            $scope.SubjectAreas=[];
            for (var i = 0; i < sareas.length; i++) {
                $scope.SubjectAreas[i] = ((sareas[i].getName()).replace('"', '')).replace('"', '');
            }
            $scope.SelectedSubjectAreas;
            // console.log($scope.SelectedSubjectAreas);
            //Function to find Selected subject areas,Tables from dropdown
            $scope.SelectedSA = function(){
               // alert("SelectedSA");
               //($scope.dataSet='';)-->On Subject area change, we are removing all the data from the dataSet variable. So that user can get the fresh data by selecting columns.
               $scope.dataSet='';
               //$scope.selectedCols = [];-->On Subject area change, we are removing all the selected columns from the variable . So that user can select the fresh columns from selected Subject area.
               $scope.selectedCols = [];
              
                $scope.SelectedSubjectAreas;
              
                var ms = new SAWSOAP_MetadataServiceSoap();
                ms.url = buildURL('metadataService');
                var detailsLevel = "IncludeTables";
                ms.describeSubjectArea(describeSubjectAreaSuccessCallback,
                        describeSubjectAreaErrorCallback, $scope.SelectedSubjectAreas,
                        detailsLevel, sessionId);
                    //	console.log($scope.SelectedSubjectAreas);
                //Loop to select tables list
                
                for(var i=0;i<tables.length;i++){
                        
                        $scope.tableName[i] = (((tables[i].getName()).replace('"', '')).replace('"','')).trim();
                      //  tables_list[i]=$scope.tableName[i] ;
                        tables_list.push( {
                            label: $scope.tableName[i] ,
                            children: [{}]
                          });

                }  
               
            }		
          
    // Capture Selected columns
 
    
            $scope.toggle = function (item,SelectedSubjectAreas,selTables, selectedCols1) {
                item = "\""+SelectedSubjectAreas+"\".\""+selTables+"\".\""+item+"\"";
                var idx = selectedCols1.indexOf(item);
            //	alert(idx);
                if (idx > -1) {
                    selectedCols1.splice(idx, 1);
                    console.log('If');
                }
                else {
                    selectedCols1.push(item);
                    console.log('Else');
                }
              };
        
              $scope.exists = function (item,SelectedSubjectAreas,selTables, selectedCols1) {
                 item = "\""+SelectedSubjectAreas+"\".\""+selTables+"\".\""+item+"\"";
                    return selectedCols1.indexOf(item) > -1;
                    console.log('Exists');
              };
              
    // Capture Selected columns Data
    $scope.colList = [];
    $scope.dataSet ;
    var sqlQuery ; 
            $scope.getColumnsData = function () {
                console.log('$scope.selectedCols.length '+ $scope.selectedCols.length)
                if($scope.selectedCols.length > 0) {
                for (var i = 0; i < $scope.selectedCols.length; i++) {
                    $scope.colList[i] = $scope.selectedCols[i];
    
                    console.log( $scope.selectedCols[i]+',');
                }
                sqlQuery = 'SELECT  ' + $scope.selectedCols + ' from '+ "\""+$scope.SelectedSubjectAreas+"\"";
            }
            else{
                sqlQuery = 'SELECT  0 from ' + "\""+$scope.SelectedSubjectAreas+"\"";
            }
                
            console.log(sqlQuery);
            //Getting Data
            var outputFormat = 'SAWRowsetData';
        // execution options object.
            var executionOptions = new SAWSOAP_XMLQueryExecutionOptions();
            executionOptions.setAsync(false);
            executionOptions.setMaxRowsPerPage(10);
            executionOptions.setRefresh(true);
            executionOptions.setPresentationInfo(false);
            executionOptions.setType('sqlQueryResult');
            
            var xvs = new SAWSOAP_XmlViewServiceSoap();
            
            //We need to get URL from 'genericURL'.
            xvs.url = genericURL +'xmlViewService';
            
            xvs.executeSQLQuery(getDataSuccessCallback, getDataErrorCallback,
                    sqlQuery, outputFormat, executionOptions, sessionId);
                    $scope.dataSet = dataRowset;
            console.log($scope.dataSet);
            }
    
            
    //Loggingoff session
    $scope.logOffMsg;
    $scope.logOffFlag;
    $scope.logOff = function () {
        getCurrentUser(); // This function gives current user loggedin
        //console.log(user);
        var ss = new SAWSOAP_SAWSessionServiceSoap();
        //The below URL is hardcoded. We have to made it dynamic
        ss.url = "http://166.78.244.8:9522/analytics/saw.dll?SoapImpl=nQSessionService";
        ss.logoff(logoffSuccessCallback, logoffErrorCallback, sessionId);
        $scope.logOffMsg = 'User '+user+' '+vizLogoffMessage;
        $scope.logOffFlag = logOffFlag;
        console.log($scope.logOffMsg);
        if ($scope.logOffFlag)
        {
            $location.path('/');
            //The below command just executes to reset application  to index page
            location.reload();
        }
    }
    
    $scope.my_data = tables_list;
    
    $scope.my_tree_handler = function(branch) {
        var ms = new SAWSOAP_MetadataServiceSoap();
        ms.url = buildURL('metadataService');
        var detailsLevel = "IncludeColumns";
       

        for(var i=0;i<tables_list.length;i++){ 
            if(branch.label == tables_list[i].label){
                tables_list[i].children =[];
                ms.describeTable(describeTableSuccessCallback, describeTableErrorCallback,
                    $scope.SelectedSubjectAreas,branch.label, detailsLevel, sessionId);
                for (var j = 0; j < columns.length; j++) {
                    $scope.colName[j] = ((columns[j].getName()).replace('"', '')).replace('"', '');
                    console.log($scope.colName[j]);
                   
                    tables_list[i].children.push( $scope.colName[j]);
                } 
                 console.log("Clicked Table  :  "+tables_list[i].label);
            }
        }


        var _ref;
        $scope.output = "You selected: " + branch.label +"Parent  :  "+parent_val;
        console.log($scope.output);
        console.log("Heloooooo..."+(JSON.stringify(branch.children.length)));
        if(JSON.stringify(branch.children.length)== 0){
        $scope.selectedCols.push('"'+parent_val+'".'+'"'+branch.label+'"');
       
        }
       // console.log("Selected Columns  " +$scope.selectedCols);
        //we are setting parent_val to empty to get the accurate parents of the childs
        parent_val ='';
        
      };  
       
    }]);

   