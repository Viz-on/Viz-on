function vizSankyGraph(data) {
    Highcharts.chart('vizHighChartontainer', {

        title: {
            text: 'Highcharts Sankey Diagram'
        },
    
        series: [{
            keys: ['from', 'to', 'weight'],
            data: 
                data
            ,
            type: 'sankey',
            name: 'Sankey Graph by VizOn Application'
        }]
    
    });

}